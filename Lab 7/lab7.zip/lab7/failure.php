<!DOCTYPE html>
<html>
        <head>
                <title>CS3380 Lab 7</title>
                 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css"><!-- Latest compiled and minified CSS -->
                <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css"><!-- Optional theme -->
                <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script><!-- Latest compiled and minified JavaScript -->
        </head>
        <body>
                <div class="container">
                        <h3>Uh Oh! FAILURE!</h3>
			<p>Check that your input types are correct.</p>
                        <a href="index.php" class="btn btn-info">Return Home</a>
                </div>
        </body>
</html>

